"""
أوامر البداية والقائمة الرئيسية، ومعالجة روابط الشراء السريعة القادمة من القناة العامة.
"""

import logging
from decimal import Decimal
from html import escape

from aiogram import Router, F
from aiogram.filters import CommandStart, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery

logger = logging.getLogger(__name__)

from keyboards.main_menu import build_main_menu
from keyboards.common import check_subscription_kb
from services.branding_service import BrandingService
from services.referral_guard_service import ReferralGuardService
from keyboards.numbers import confirm_purchase_kb
from providers.countries import get_number_service_by_code
from providers.manager import provider_manager
from services.currency_service import CurrencyService
from services.subscription_service import SubscriptionService
from services.settings_service import SettingsService
from services.pricing_service import PricingService
from services.price_lock_service import PriceLockService
from services.i18n_service import I18nService

router = Router(name="start")


async def _build_menu(session, db_user):
    """بناء القائمة الرئيسية بلغة وعملة المستخدم."""
    from services.feature_service import FeatureService

    language = db_user.language_code
    balance_display = await CurrencyService.format_user_amount(
        db_user.balance, db_user, session
    )
    show_agent = await FeatureService.enabled("agent_program")
    agent_percent = str(
        await FeatureService.config("agent_program", "default_percent", 10)
    )
    completed_orders = await _completed_orders_count(session, db_user.id)
    show_ai = await _ai_section_visible(session)
    show_whatsapp = await FeatureService.enabled("whatsapp_section")
    # سوق المستخدمين يظهر فقط إذا كانت ميزة الوساطة مفعّلة من لوحة الأدمن.
    from services.marketplace_service import MarketplaceService

    show_marketplace = await MarketplaceService.enabled()
    return build_main_menu(
        number_services=[],
        categories=[],
        balance_usd=f"{db_user.balance:.2f}",
        language=language,
        balance_display=balance_display,
        show_marketplace=show_marketplace,
        show_agent=show_agent,
        agent_percent=agent_percent,
        completed_orders_count=completed_orders,
        show_ai=show_ai,
        show_whatsapp=show_whatsapp,
    )


async def _ai_section_visible(session) -> bool:
    """زر الذكاء الاصطناعي يظهر إذا فُعّلت الميزة وفيه قسم مفعّل."""
    from sqlalchemy import func, select

    from database.models import AiSection
    from services.feature_service import FeatureService

    if not await FeatureService.enabled("ai_sections"):
        return False
    count = await session.scalar(
        select(func.count(AiSection.id)).where(AiSection.enabled.is_(True))
    )
    return bool(count)


async def _completed_orders_count(session, user_id: int | None = None) -> int:
    """طلبات المستخدم المنجزة لزر الإنجازات — لا إجمالي المنصة.

    الإصلاح: كان يحسب إجمالي كل المستخدمين فيعرض رقماً مضللاً كأنه إنجازك.
    """
    from sqlalchemy import func, select
    from database.models import NumberOrder, OrderStatus, UnifiedOrder, UnifiedOrderStatus

    if user_id is None:
        return 0
    number_count = (
        await session.execute(
            select(func.count(NumberOrder.id)).where(
                NumberOrder.status == OrderStatus.COMPLETED,
                NumberOrder.user_id == user_id,
            )
        )
    ).scalar_one()
    unified_count = (
        await session.execute(
            select(func.count(UnifiedOrder.id)).where(
                UnifiedOrder.status == UnifiedOrderStatus.COMPLETED,
                UnifiedOrder.user_id == user_id,
            )
        )
    ).scalar_one()
    return int(number_count or 0) + int(unified_count or 0)


async def _pending_orders_hint(session, db_user) -> str:
    """سطر «طلباتك قيد التنفيذ» حتى لا ينسى الزبون طلباً لم يكتمل."""
    try:
        from sqlalchemy import func, select

        from database.models import (
            NumberOrder,
            OrderStatus,
            UnifiedOrder,
            UnifiedOrderStatus,
        )

        unified = await session.scalar(
            select(func.count(UnifiedOrder.id)).where(
                UnifiedOrder.user_id == db_user.id,
                UnifiedOrder.status.in_(
                    (UnifiedOrderStatus.PENDING, UnifiedOrderStatus.PROCESSING)
                ),
            )
        )
        numbers = await session.scalar(
            select(func.count(NumberOrder.id)).where(
                NumberOrder.user_id == db_user.id,
                NumberOrder.status == OrderStatus.PENDING,
            )
        )
        total = int(unified or 0) + int(numbers or 0)
    except Exception:  # noqa: BLE001 — سطر تجميلي لا يُسقط الشاشة الأولى
        return ""
    if total <= 0:
        return ""
    if str(getattr(db_user, "language_code", "ar") or "ar").startswith("en"):
        return f"\n\u23f3 <b>{total}</b> order(s) still in progress — follow them from \u00abMy Account\u00bb."
    return f"\n\u23f3 \u0644\u062f\u064a\u0643 <b>{total}</b> \u0637\u0644\u0628 \u0642\u064a\u062f \u0627\u0644\u062a\u0646\u0641\u064a\u0630 \u2014 \u062a\u0627\u0628\u0639\u0647\u0627 \u0645\u0646 \u00ab\u062d\u0633\u0627\u0628\u064a \u2190 \u0637\u0644\u0628\u0627\u062a\u064a\u00bb."


async def _main_header(session, db_user) -> str:
    """رأس القائمة الرئيسية: هوية المتجر + الميزات + الرصيد بعملته المحلية."""
    balance_text = await CurrencyService.format_dual(db_user.balance, db_user, session)
    hint = await _pending_orders_hint(session, db_user)
    try:
        text = await BrandingService.main_menu_header(
            balance_text,
            getattr(db_user, "language_code", "ar") or "ar",
        )
    except Exception:  # noqa: BLE001 — لا تُسقط الشاشة الأولى بسبب نص تجميلي
        logger.exception("تعذر بناء رأس القائمة الرئيسية، استخدام النص الافتراضي")
        text = I18nService.t(
            "main_menu_header",
            db_user.language_code,
            balance=balance_text,
        )
    return f"{text}{hint}" if hint else text


async def _alternatives_kb(session, service, missing_code: str):
    """بدائل متاحة الآن عندما تنفد الدولة القادمة من قناة التوفر."""
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
    from services.number_catalog_service import build_board, format_price

    buttons: list[list[InlineKeyboardButton]] = []
    try:
        entries = await build_board(session, service, use_cache=True)
    except Exception:  # noqa: BLE001
        entries = []
    for entry in entries:
        if str(entry.code).lower() == str(missing_code).lower():
            continue
        buttons.append(
            [
                InlineKeyboardButton(
                    text=f"🟢 {entry.flag} {entry.name_ar} — {format_price(entry.sell_usd)}$",
                    callback_data=f"num_country:{service.code}:{entry.cid}", style="success",
                )
            ]
        )
        if len(buttons) >= 5:
            break
    buttons.append(
        [InlineKeyboardButton(text="🔄 كل الدول المتاحة", callback_data=f"num_svc:{service.code}", style="success")]
    )
    buttons.append([InlineKeyboardButton(text="🏠 القائمة الرئيسية", callback_data="back_to_main")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


@router.message(CommandStart())
async def cmd_start(message: Message, command: CommandObject, session, db_user, state: FSMContext):
    # 1. التحقق من الاشتراك الإجباري بالقنوات
    is_ok, missing = await SubscriptionService.is_user_subscribed_all(
        message.bot, session, db_user.telegram_id
    )

    if not is_ok and not db_user.is_admin:
        await message.answer(
            I18nService.t("subscribe_first", db_user.language_code),
            reply_markup=check_subscription_kb(missing),
        )
        return

    # 1.5 التحقق البشري لروابط الإحالة (حماية من البوتات):
    # لا يُفعَّل الحساب ولا تُدفع مكافأة المحيل قبل نجاح الاختبار.
    if await ReferralGuardService.requires_check(db_user):
        from handlers.referral_guard import send_human_check

        await send_human_check(message, state, db_user)
        return
    if db_user.referral_check_pending:
        # الميزة معطلة حالياً → نلغي الانتظار ونتابع كالمعتاد.
        db_user.referral_check_pending = False
        await session.commit()

    # 2. تفعيل المستخدم ومكافأة الإحالة
    if not db_user.is_activated:
        db_user.is_activated = True
        await session.commit()
        await _try_pay_referral_bonus(session, db_user, message.bot)

    # 3. معالجة روابط المنتجات/الشراء السريع القادمة من inline أو قناة التوفر
    args = command.args
    if args and args.startswith("prod_"):
        try:
            product_id = int(args.replace("prod_", "", 1))
        except ValueError:
            product_id = 0
        if product_id:
            from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
            from database.models import ProductStatus
            from services.dynamic_service import DynamicService

            product = await DynamicService.get_product(session, product_id)
            if product and product.status == ProductStatus.ACTIVE:
                price_display = await CurrencyService.format_dual(product.price_usd, db_user, session)
                await message.answer(
                    f"🛍 <b>{escape(product.name_ar)}</b>\n\n"
                    f"{escape(product.description or 'خدمة رقمية جاهزة للطلب')}\n\n"
                    f"💰 <b>السعر:</b> {price_display}\n\n"
                    "اضغط شراء للانتقال لخطوات الطلب داخل البوت:",
                    reply_markup=InlineKeyboardMarkup(
                        inline_keyboard=[
                            [InlineKeyboardButton(text="🛒 شراء الآن", callback_data=f"prod:{product.id}", style="success")],
                            [InlineKeyboardButton(text="🟢 🛍 المتجر", callback_data="store:home", style="success")],
                        ]
                    ),
                )
                return

    if args and args.startswith("buy_"):
        raw_payload = args.replace("buy_", "", 1)
        if "__" in raw_payload:
            from providers.countries import resolve_country

            service_code, country_ref = raw_payload.split("__", 1)
            service = await get_number_service_by_code(session, service_code)
            country = await resolve_country(session, country_ref)

            if service and country and country.is_active:
                country_code = country.code
                prices = await provider_manager.get_cheapest_price(service, country, session)
                from services.country_localization_service import display_flag, display_name

                if not prices:
                    # التوفر المتقطع: الرقم قد ينفد بين نشر اللوحة وضغط الزر.
                    # بدل رسالة مسدودة نعرض بدائل متاحة الآن فوراً.
                    await message.answer(
                        I18nService.t(
                            "no_numbers_available",
                            db_user.language_code,
                            country=f"{display_flag(country)} {display_name(country)}",
                            service=service.name_ar,
                        ),
                        reply_markup=await _alternatives_kb(session, service, country.code),
                    )
                    return
                cheapest_provider = min(prices, key=prices.get)
                cost_usd = prices[cheapest_provider]
                sell_price = await PricingService.calculate_sell_price(
                    session, service_code, country_code, cheapest_provider, cost_usd
                )
                quote = await PriceLockService.create(
                    service_code, country_code, cheapest_provider.value, cost_usd, sell_price
                )

                price_display = await CurrencyService.format_dual(sell_price, db_user, session)
                await message.answer(
                    f"⚡ <b>طلب رقم سريع من القناة العامة:</b>\n\n"
                    f"🌍 <b>الدولة:</b> {display_flag(country)} {display_name(country)}\n"
                    f"{service.emoji} <b>الخدمة:</b> {service.name_ar}\n"
                    f"💰 <b>السعر:</b> <b>{price_display}</b>\n\n"
                    "🛡 <b>الضمان:</b> استرجاع تلقائي في حال لم يصل الكود.\n\n"
                    "اضغط على الزر أدناه لإتمام الشراء فوراً:",
                    reply_markup=confirm_purchase_kb(service_code, country.id, quote.token),
                )
                return

    if args in ("tgready", "tgr") or (args and args.startswith("tgr_")):
        from handlers.tg_ready import present_tg_ready

        country_key = args[4:] if args.startswith("tgr_") else None
        await present_tg_ready(message, session, db_user, country_key or None)
        return

    # 4. رسالة الترحيب الافتراضية
    default_name = "friend" if db_user.language_code == "en" else "عزيزي"
    welcome_msg = await SettingsService.get(
        "welcome_message",
        I18nService.t(
            "welcome",
            db_user.language_code,
            name=message.from_user.full_name or default_name,
        ),
    )
    welcome_msg = welcome_msg.replace(
        "{name}", message.from_user.full_name or default_name
    )

    menu_kb = await _build_menu(session, db_user)
    await message.answer(welcome_msg, reply_markup=menu_kb)


@router.callback_query(F.data == "back_to_main")
async def back_to_main(callback: CallbackQuery, session, db_user):
    """زر الرجوع للقائمة الرئيسية."""
    await callback.answer()
    await _render_main_menu(callback, session, db_user)


async def _render_main_menu(target, session, db_user) -> None:
    """رسم الشاشة الرئيسية (رسالة الحالية أو رسالة جديدة عند الفشل)."""
    menu_kb = await _build_menu(session, db_user)
    header = await _main_header(session, db_user)
    try:
        await target.message.edit_text(header, reply_markup=menu_kb)
    except Exception:
        await target.message.answer(header, reply_markup=menu_kb)


@router.callback_query(F.data == "flow:cancel")
async def flow_cancel(callback: CallbackQuery, session, db_user, state: FSMContext):
    """إلغاء عملية جارية (إدخال معرّف/رابط/مبلغ) والرجوع للقائمة الرئيسية."""
    await state.clear()
    await callback.answer("❌ تم إلغاء العملية.")
    await _render_main_menu(callback, session, db_user)


async def _try_pay_referral_bonus(session, user, bot):
    """دفع مكافأة الإحالة."""
    from database.models import User, TransactionType
    from services.balance_service import BalanceService
    from services.notification_service import NotificationService

    if user.referrer_id is None or user.referral_bonus_paid:
        return

    require_sub = await SettingsService.get_bool("require_subscription_for_referral", True)
    if require_sub and not user.is_activated:
        return

    referrer = await session.get(User, user.referrer_id)
    if referrer is None:
        return

    bonus_usd = await SettingsService.get_decimal("referral_bonus_usd", Decimal("0.015"))

    if bonus_usd <= 0:
        return

    await BalanceService.add_balance(
        session,
        referrer.id,
        bonus_usd,
        TransactionType.REFERRAL_BONUS,
        description=f"مكافأة إحالة عن المستخدم {user.telegram_id}",
    )
    user.referral_bonus_paid = True
    await session.commit()

    notifier = NotificationService(bot)
    await notifier.notify_user(
        referrer.telegram_id,
        I18nService.t(
            "referral_bonus_notification",
            referrer.language_code,
            amount=f"{bonus_usd}",
        ),
    )


@router.callback_query(F.data == "check_subscription")
async def check_subscription_callback(
    callback: CallbackQuery,
    session,
    db_user,
    bot,
    state: FSMContext,
):
    """التحقق من الاشتراك بالقنوات الإجبارية."""
    is_ok, missing = await SubscriptionService.is_user_subscribed_all(
        bot, session, db_user.telegram_id
    )

    if is_ok:
        # التحقق البشري أولاً لمن دخل عبر رابط إحالة.
        if await ReferralGuardService.requires_check(db_user):
            await callback.answer()
            from handlers.referral_guard import send_human_check

            await send_human_check(callback.message, state, db_user)
            return
        if db_user.referral_check_pending:
            # الميزة معطلة حالياً → نلغي الانتظار.
            db_user.referral_check_pending = False
            await session.commit()
        if not db_user.is_activated:
            db_user.is_activated = True
            await session.commit()
            await _try_pay_referral_bonus(session, db_user, bot)

        await callback.message.edit_text(
            I18nService.t("subscription_verified", db_user.language_code)
        )
        menu_kb = await _build_menu(session, db_user)
        header = await _main_header(session, db_user)
        await callback.message.answer(header, reply_markup=menu_kb)
    else:
        await callback.answer(
            I18nService.t("subscription_still_missing", db_user.language_code),
            show_alert=True,
        )