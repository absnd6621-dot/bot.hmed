"""
لوحة تحكم الأدمن الرئيسية.
"""

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from keyboards.admin import ADMIN_TABS, admin_main_kb, admin_maintenance_kb, admin_tab_kb
from services.settings_service import SettingsService
from states.states import AdminMaintenanceStates
from filters.admin_filter import IsAdmin

router = Router(name="admin_panel")
router.message.filter(IsAdmin())
router.callback_query.filter(IsAdmin())


async def _pulse_block(session) -> str:
    """سطرا النبضة — أي فشل يُرجع نصاً فارغاً بدل إسقاط اللوحة."""
    try:
        from services.admin_pulse_service import AdminPulseService

        return AdminPulseService.render(await AdminPulseService.summary(session))
    except Exception:  # noqa: BLE001
        return ""


@router.message(Command("admin"))
async def admin_entry(message: Message, session):
    pulse = await _pulse_block(session)
    await message.answer(
        "🛠 <b>لوحة تحكم الأدمن</b>\n\n"
        + (f"{pulse}\n\n" if pulse else "")
        + "اختر أحد التبويبات الرئيسية للوصول السريع بدون ازدحام.",
        reply_markup=admin_main_kb(),
    )


@router.callback_query(F.data == "admin:main")
async def admin_main_callback(callback: CallbackQuery, session):
    pulse = await _pulse_block(session)
    await callback.message.edit_text(
        "🛠 <b>لوحة تحكم الأدمن</b>\n\n"
        + (f"{pulse}\n\n" if pulse else "")
        + "اختر تبويباً رئيسياً لإدارة القسم المطلوب بدل قائمة طويلة مزدحمة.",
        reply_markup=admin_main_kb(),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("admin:tab:"))
async def admin_tab_callback(callback: CallbackQuery):
    tab = (callback.data or "").rsplit(":", 1)[-1]
    if tab not in ADMIN_TABS:
        await callback.answer("تبويب غير معروف.", show_alert=True)
        return
    title, items = ADMIN_TABS[tab]
    bullets = "\n".join(f"• {label}" for label, _data in items)
    await callback.message.edit_text(
        f"{title}\n\n{bullets}\n\nاختر من الأزرار بالأسفل:",
        reply_markup=admin_tab_kb(tab),
    )
    await callback.answer()


# ══════════════ آخر التحديثات والإضافات ══════════════

# كل ما أُنجز في التحديث الكبير الحالي — يُعرض للأدمن من زر
# «🆕 آخر التحديثات والإضافات». أضف أي مرحلة جديدة هنا.
CHANGELOG_ENTRIES: list[tuple[str, str, str]] = [
    (
        "📲",
        "إيداع رصيد الجوال (MTN/Syriatel)",
        "طريقة دفع جديدة «📲 رصيد جوال» من ميزة <b>mobile_credit_deposit</b> "
        "(مركز الإضافات). المستخدم يرسل رقم الجوال والمبلغ، ويُنشأ طلب إيداع "
        "بالمبلغ المعادل ويُعرض على الأدمن بقبول/رفض — القبول يضيف الرصيد "
        "تلقائياً. السقوف (1-250$).",
    ),
    (
        "🎁",
        "اشحن لأهلك من وديعتهم",
        "ميزة <b>mobile_topup_gift</b>: من قسم «المكافآت» يستطيع المستخدم "
        "شحن رصيد جوال لأي رقم (MTN/Syriatel) من رصيده. يُنشأ طلب بحالة "
        "«بانتظار التنفيذ» ويظهر للأدمن في تبويب المالية «🎁 طلبات الشحن لأهلي» "
        "بقبول (تُخصم عند التنفيذ) أو رفض بسبب يُشعر المستخدم. السقوف (1-100$).",
    ),
    (
        "🏷",
        "أكواد الحملات (كوبونات بلا كوبون)",
        "ميزة <b>campaign_codes</b>: أكواد ترويجية من لوحة الأدمن (نسبة % / "
        "مبلغ ثابت) تدخل ككود عادي عند الشراء — بدون السلة أو مدة صلاحية. "
        "إدارة كاملة: «المستخدمون والتسويق ← 🏷 أكواد الحملات»، مع سقف "
        "استخدام لكل كود وعدّاد استهلاكي.",
    ),
    (
        "🛒",
        "تحصين الشراء بفشل احتياطي تلقائي",
        "عند فشل أي مزود أثناء تنفيذ الطلب: يشغّل البوت المسار الاحتياطي "
        "فوراً ويسجّل الفشل، وميزة <b>auto_failover</b> تعزل المسار الاحتياطي "
        "تلقائياً بعد عدد فشل محدد وتنبه الأدمن، وتتلاشى العدادات مع الوقت "
        "حتى لا يبقى المسار معطلاً للأبد. كل المسارات تُجرب بالتتابع حتى "
        "ينجح التنفيذ.",
    ),
    (
        "👑",
        "حساب كاشباك مضاعف باكتساب VIP",
        "ميزة <b>vip_tiers</b>: عند تفعيلها يعرض الملف الشخصي شارة VIP "
        "ويُضرب الكاشباك النقدي على كل عملية شراء بمضاعف مستوى المستخدم "
        "(من tiers_json في مركز الإضافات).",
    ),
    (
        "💰",
        "عرض الليرة السورية بجانب السعر",
        "ميزة <b>syp_display</b>: تُظهر «≈ X ل.س» بجانب السعر بالدولار في "
        "رسائل الشراء والرصيد حتى لو كانت عملة عرض المستخدم دولاراً، "
        "بسعر الصرف الحالي. غيّر نسبة السعر من لوحة العملات.",
    ),
    (
        "💾",
        "نسخة احتياطية اختيارية من مركز الإضافات",
        "ميزة <b>db_backup_telegram</b>: نسخ يومية للقاعدة تُرسل للقناة عند "
        "الساعة 3 فجراً، مع تحديد chat_id خارجي اختياري. عند تعطيلها لا "
        "تُرسل النسخ.",
    ),
    (
        "⏱",
        "عدّاد تنازلي للعروض الخاصة 24",
        "ميزة <b>flash_sale_timer</b>: تُظهر قائمة العروض الخاصة عدّاداً "
        "تنازلياً (HH:MM:SS) بجانب كل عرض تنتهي مدته.",
    ),
    (
        "🤖",
        "القسم الرئيسي للذكاء الاصطناعي (برمجة/دردشة)",
        "قسم جديد في القائمة الرئيسية: «🤖 الذكاء الاصطناعي». من لوحة الأدمن "
        "(المتجر والخدمات ← 🤖 إدارة الذكاء الاصطناعي) تنشئ أي عدد من "
        "الأقسام — الآن: «برمجة بدون قيود» (يرسل الكود/الأداة كاملة كملف) و"
        "«دردشة بدون قيود» — وكل قسم بموديل NanoGPT تختاره أنت، وصف يدوي "
        "له، وتكلفة رسالة تقريبية. سعر المستخدم = التكلفة + ربح 3 أضعاف "
        "(قابل للضبط)، ويُخصم لكل رسالة ناجحة مع استرجاع تلقائي عند فشل "
        "المزود. جلسات المستخدمين ورسائلهم محفوظة ويعودون لها من «جلستي»، "
        "وإحصاءات التكلفة/الإيراد/الربح من اللوحة. الإضافة المستقبلية: قسم "
        "ثالث = صف جديد بلا كود.",
    ),
    (
        "🚀",
        "منتجات قسم الرشق — شاشة تحكم واحدة",
        "زر جديد «🚀 منتجات قسم الرشق» في تبويب «المتجر والخدمات والرشق»: "
        "يعرض كل التطبيقات التي فيها منتجات مع عدد منتجات كل تطبيق، ثم "
        "أقسامه الفرعية (متابعون/لايكات/مشاهدات…)، ثم منتجات القسم. داخل "
        "القسم: ضغطة على المنتج تعطّله أو تفعّله، و🗑 تحذفه بتأكيد، و«💵 "
        "نسبة الربح» تُطبَّق فوراً على كل منتجات القسم (تُعاد الأسعار من "
        "التكلفة)، مع أزرار تفعيل/تعطيل كل المنتجات دفعة واحدة وحذفها كلها "
        "مع بقاء الأقسام. وكل منتج يعرض سعره عند المزود وسعره عندنا والربح "
        "واسم المزود وآيدي الخدمة عنده.",
    ),
    (
        "📥",
        "السحب التلقائي: أرخص 10 بدل 5 وبلا خدمات صفرية",
        "البناء التلقائي لأقسام الرشق صار ينشر أرخص <b>10</b> خدمات في كل "
        "قسم داخلي بدل 5، ولم يعد ينشر أي خدمة بلا سعر (أسطر «سيرفر 1» "
        "وعناوين الأقسام التي تصل من المزود بسعر 0$)، ويظهر عددها في تقرير "
        "البناء. وللمخلّفات القديمة: زر «🧼 حذف المنتجات بلا سعر» داخل "
        "شاشة منتجات الرشق.",
    ),
    (
        "💵",
        "هامش ربح لكل تطبيق/قسم فرعي في كل قسم",
        "صار هامش القسم الفرعي (وكل خدمة بداخله مثل لايكات انستا أو "
        "متابعين تيك توك) يتحكم بأسعار منتجاتها فعلياً حتى لو كانت "
        "المنتجات سحوبة تلقائياً. من «إدارة الأقسام» ← أي قسم فرعي ← "
        "«💵 هامش ربح هذا القسم»: تضبط نسبته ويعاد حساب أسعار كل منتجات "
        "القسم فوراً، وهامش المنتج الذي يضبطه الأدمن يدوياً يبقى محترماً.",
    ),
    (
        "🧹",
        "حذف منتجات أي قسم بضغطة — مع إبقاء الأقسام الفرعية",
        "من «إدارة الأقسام»: عند فتح أي قسم رئيسي أو فرعي يوجد زر «🧹 حذف "
        "كل منتجات القسم». يحذف المنتجات فقط (القسم الفرعي والأقسام الداخلية "
        "تبقى سليمة) حتى تعيد السحب بضغطة واحدة. يعمل على كل الأقسام: رشق، "
        "ألعاب، تطبيقات، وأي قسم مخصص.",
    ),
    (
        "🖥",
        "السيرفرات/المزودين المتعددين لقسم الأرقام",
        "كل خدمة أرقام يمكن أن تحوي عدة سيرفرات (مزودين). قبل أن يرى "
        "المستخدم الدول يختار السيرفر الذي يناسبه، وكل سيرفر مربوط بمزود "
        "مستقل. من لوحة الأدمن: «إدارة خدمات الأرقام» ← أي خدمة ← «⚙️ "
        "السيرفرات/المزودين التابعين» لإضافة/تعطيل/تغيير المزود أو إنشاء "
        "سيرفر لكل مزود مضبوط تلقائياً — بلا تعديل كود.",
    ),
    (
        "🖥",
        "السيرفرات العامة — لكل الأقسام (متجر/رشق/ألعاب/أرقام)",
        "لم يعد نظام السيرفرات خاصاً بالأرقام فقط. من زر «🖥 السيرفرات "
        "العامة» في تبويب المتجر يضيف الأدمن سيرفراً جديداً مرتبطاً "
        "بقسم رئيسي أو فرعي أو بكل الأقسام، ويربطه بمزود (متجر/رشق/ألعاب) "
        "ويضبط نسبة ربح مستقلة. السيرفر يظهر تلقائياً للمستخدم قبل عرض "
        "المنتجات، ويُطبق هامش ربحه عند الشراء تلقائياً.",
    ),
    (
        "🔌",
        "إدارة «الخدمات المسحوبة» لكل مزود لحاله",
        "تبويب «المتجر والخدمات والرشق» في لوحة الأدمن أُعيد ترتيبه. "
        "داخل «الخدمات المسحوبة» يوجد الآن زر «إدارة كل مزود لحاله»: "
        "لكل مزود شاشة فيها بحث خاص به، كتالوجه كاملاً الأرخص أولاً، "
        "نشر أرخص 10 لكل نوع ضمن قسم الرشق، ومزامنة كاملة كقسم باسمه، "
        "و«مسح كل منتجات المزود من المتجر» ثم إعادة السحب بضغطة واحدة.",
    ),
    (
        "🧹",
        "إصلاح أخطاء «بعد أول ضغطة»",
        "أصبحت الأزرار القديمة (عرض المنتجات/إضافة منتج من شاشة القسم) "
        "تعمل بدل «زر غير معالج». أُصلح Error: KeyError عند إرسال Player ID "
        "لخدمة منتهية الجلسة، وحادثة «الرسالة القديمة لم تعد قابلة للتعديل» — "
        "الآن يرسل البوت رسالة جديدة بدل أن يفشل.",
    ),
    (
        "🛍",
        "زر المتجر الرئيسي",
        "زر «متجر» في القائمة الرئيسية يعرض كل الأقسام، "
        "مع زر «🛍 التحكم بالمتجر» لإظهاره/إخفائه عن المستخدمين.",
    ),
    (
        "🔢",
        "شبكة الأرقام",
        "25 رقم في الصفحة جنباً إلى جنب (شبكة مربعة) من الأرخص للأغلى، "
        "مع ترجمة أسماء الدول مع العلم والسعر.",
    ),
    (
        "📡",
        "لوحة التوفر",
        "لوحة تعرض الأرقام المتاحة لكل خدمة لحظياً.",
    ),
    (
        "💼",
        "برنامج الوكلاء",
        "كود إحالة (AGENT-XXXX-XXXX) يعطي خصماً على كل الخدمات، "
        "مع عمولة وإلغاء تلقائي أسبوعياً إن لم تحقق الحد الأدنى.",
    ),
    (
        "💵",
        "تحكم كامل بهوامش الربح",
        "هامش مستقل لكل منتج/قسم فرعي/قسم/عام، ويُطبق بالترتيب: "
        "المنتج ← القسم الفرعي ← القسم ← العام.",
    ),
    (
        "🌍",
        "ترجمة الخدمات المسحوبة تلقائياً",
        "كل خدمة تسحبها من أي مزود تُترجم للعربية عند إضافتها، "
        "بدون التأثير على الاتصال بالمزود — والأسماء المجهولة تبقى كما هي.",
    ),
    (
        "🎛",
        "سلطة كاملة على الأقسام والمنتجات",
        "شرح قابل للتعديل من الأدمن لكل قسم (رئيسي/فرعي/داخلي) ولكل "
        "خدمة، ويظهر للمستخدم، مع إمكانية إضافة قسم داخلي داخل أي قسم فيه منتجات.",
    ),
    (
        "🏬",
        "ربط أي متجر خارجي (Hyper Store)",
        "اربط أي متجر خارجي فيه API من اللوحة بدون تعديل كود البوت. "
        "زر «🏬 مزامنة متجر كامل ← قسم باسم المتجر» يسحب كل خدماته "
        "لقسم باسمه (بالعربية، التكلفة + الهامش، من الأرخص للأغلى) "
        "وإعادة المزامنة لا تكرّر.",
    ),
    (
        "🖐",
        "المنتجات اليدوية",
        "أنشئ منتجاً يدوياً: المشتري يُشعر أن طلبه يدوي وسيُنفذ لاحقاً، "
        "وقناة الإدارة تنبّه بأزرار قبول/رفض — قبول = إشعار المستخدم "
        "بالتنفيذ، رفض = استرجاع + إشعار.",
    ),
    (
        "🛍",
        "الاشتراكات الرقمية برصد ميزان المزود",
        "قبل إرسال الطلب يُفحص رصيد المزود: إن كان غير كافٍ لا يُرسل "
        "والمشتري يُشعر أن الكود سيصل خلال دقائق، وتُنبه القناة بأزرار "
        "نعم/لا — نعم = أرسل البيانات يدوياً ويُشعر المشتري، "
        "لا = إلغاء + استرجاع.",
    ),
]


def _changelog_chunks(entries: list[tuple[str, str, str]]) -> list[str]:
    """يقسّم التحديثات إلى رسائل ضمن حد تيليجرام."""
    header = "🆕 <b>آخر التحديثات والإضافات</b>\n\n"
    chunks: list[str] = []
    current = header
    limit = 4000
    for emoji, title, desc in entries:
        block = f"{emoji} <b>{title}</b>\n{desc}\n\n"
        if len(current) + len(block) > limit and len(current) > len(header):
            chunks.append(current.rstrip())
            current = header
        current += block
    chunks.append(current.rstrip())
    return chunks


@router.callback_query(F.data == "admin:changelog")
async def admin_changelog(callback: CallbackQuery):
    await callback.answer()
    chunks = _changelog_chunks(CHANGELOG_ENTRIES)
    first = chunks[0]
    if len(chunks) == 1:
        await callback.message.edit_text(
            first,
            reply_markup=admin_main_kb(),
        )
        return
    # أكثر من رسالة: الأخيرة تحمل زر الرجوع للوحة
    for text in chunks[1:-1]:
        await callback.message.answer(text)
    last = chunks[-1] + "\n\n🔙 <b>للعودة للوحة الرئيسية</b>"
    await callback.message.answer(
        last,
        reply_markup=admin_main_kb(),
    )


# ══════════════ وضع الصيانة ══════════════


@router.callback_query(F.data == "admin:maintenance")
async def maintenance_menu(callback: CallbackQuery):
    is_active = await SettingsService.get_bool("maintenance_mode", False)
    current_msg = await SettingsService.get("maintenance_message", "⚙️ البوت تحت الصيانة حالياً...")
    status = "🔴 مفعّل" if is_active else "🟢 غير مفعّل"
    await callback.message.edit_text(
        f"🔧 <b>وضع الصيانة</b>\n\n"
        f"الحالة: {status}\n\n"
        f"📝 رسالة الصيانة الحالية:\n"
        f"<i>{current_msg}</i>",
        reply_markup=admin_maintenance_kb(is_active),
    )


@router.callback_query(F.data == "admin:maintenance_on")
async def maintenance_on(callback: CallbackQuery, session):
    await SettingsService.set(session, "maintenance_mode", "true")
    await callback.answer("✅ تم تفعيل وضع الصيانة.")
    await maintenance_menu(callback)


@router.callback_query(F.data == "admin:maintenance_off")
async def maintenance_off(callback: CallbackQuery, session):
    await SettingsService.set(session, "maintenance_mode", "false")
    await callback.answer("✅ تم إيقاف وضع الصيانة.")
    await maintenance_menu(callback)


@router.callback_query(F.data == "admin:maintenance_msg")
async def maintenance_msg_start(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text("📝 أرسل رسالة الصيانة الجديدة:")
    await state.set_state(AdminMaintenanceStates.waiting_message)


@router.message(AdminMaintenanceStates.waiting_message)
async def maintenance_msg_received(message: Message, state: FSMContext, session):
    await SettingsService.set(
        session,
        "maintenance_message",
        message.text.strip(),
    )
    await message.answer(
        "✅ تم تحديث رسالة الصيانة.",
        reply_markup=admin_main_kb(),
    )
    await state.clear()
